﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp.pageAdmin;

namespace TrainingCoursesApp.pageApp.pageAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageAdminCourseAdd.xaml
    /// </summary>
    public partial class PageAdminCourseAdd : Page
    {
        public int idCourse = 0;
        public PageAdminCourseAdd()
        {
            InitializeComponent();

            cmbOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
            cmbOrganization.SelectedValuePath = "OrganizationID";
            cmbOrganization.DisplayMemberPath = "Title";

            cmbCourseForm.ItemsSource = ClassDataBase.trainingCourses.CourseForm.ToList();
            cmbCourseForm.SelectedValuePath = "CourseFormID";
            cmbCourseForm.DisplayMemberPath = "Title";

            cmbQualification.ItemsSource = ClassDataBase.trainingCourses.Qualification.ToList();
            cmbQualification.SelectedValuePath = "QualificationID";
            cmbQualification.DisplayMemberPath = "Title";
        }

        public PageAdminCourseAdd(Course course)
        {
            InitializeComponent();

            idCourse = course.CourseID;

            Title = "Изменение курса";

            cmbOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
            cmbOrganization.SelectedValuePath = "OrganizationID";
            cmbOrganization.DisplayMemberPath = "Title";

            cmbCourseForm.ItemsSource = ClassDataBase.trainingCourses.CourseForm.ToList();
            cmbCourseForm.SelectedValuePath = "CourseFormID";
            cmbCourseForm.DisplayMemberPath = "Title";

            cmbQualification.ItemsSource = ClassDataBase.trainingCourses.Qualification.ToList();
            cmbQualification.SelectedValuePath = "QualificationID";
            cmbQualification.DisplayMemberPath = "Title";

            txbxProgram.Text = course.Program;
            txbxPlanStart.Text = course.PlanStart.ToString();
            txbxPlanEnd.Text = course.PlanEnd.ToString();
            txbxCountPeopleMax.Text = course.CountPeopleMax.ToString();
            txbxDescription.Text = course.Description;
            txbxPerson.Text = course.Percon;

            cmbOrganization.SelectedItem = course.Organization;
            cmbQualification.SelectedItem = course.Qualification;
            cmbCourseForm.SelectedItem = course.CourseForm;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (idCourse == 0)
            {
                try
                {
                    if (txbxCountPeopleMax.Text == "")
                    {
                        Course course = new Course()
                        {
                            Program = txbxProgram.Text,
                            IDOrganization = (cmbOrganization.SelectedItem as Organization).OrganizationID,
                            PlanStart = Convert.ToDateTime(txbxPlanStart.Text),
                            PlanEnd = Convert.ToDateTime(txbxPlanEnd.Text),
                            IDCourseForm = (cmbCourseForm.SelectedItem as CourseForm).CourseFormID,
                            IDStatus = 1,
                            IDQualification = (cmbQualification.SelectedItem as Qualification).QualificationID,
                            Percon = txbxPerson.Text,
                            Description = txbxDescription.Text
                        };
                        ClassDataBase.trainingCourses.Course.Add(course);
                    }
                    else
                    {
                        Course course = new Course()
                        {
                            Program = txbxProgram.Text,
                            IDOrganization = (cmbOrganization.SelectedItem as Organization).OrganizationID,
                            PlanStart = Convert.ToDateTime(txbxPlanStart.Text),
                            PlanEnd = Convert.ToDateTime(txbxPlanEnd.Text),
                            CountPeopleMax = int.Parse(txbxCountPeopleMax.Text),
                            IDCourseForm = (cmbCourseForm.SelectedItem as CourseForm).CourseFormID,
                            IDStatus = 1,
                            IDQualification = (cmbQualification.SelectedItem as Qualification).QualificationID,
                            Percon = txbxPerson.Text,
                            Description = txbxDescription.Text
                        };
                        ClassDataBase.trainingCourses.Course.Add(course);
                    }
                    ClassDataBase.trainingCourses.UpdateCourseHoursPeopleCount();
                    ClassDataBase.trainingCourses.UpdateStatusInProcess();
                    ClassDataBase.trainingCourses.UpdateStatusEnd();
                    ClassDataBase.trainingCourses.SaveChanges();
                    ClassFrame.frame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                try
                {
                    ClassDataBase.trainingCourses.UpdateCourse(idCourse, txbxProgram.Text, (cmbOrganization.SelectedItem as Organization).OrganizationID,
                        Convert.ToDateTime(txbxPlanStart.Text), Convert.ToDateTime(txbxPlanEnd.Text), int.Parse(txbxCountPeopleMax.Text),
                        (cmbCourseForm.SelectedItem as CourseForm).CourseFormID, (cmbQualification.SelectedItem as Qualification).QualificationID,
                        txbxPerson.Text, txbxDescription.Text);
                    ClassDataBase.trainingCourses.UpdateCourseHoursPeopleCount();
                    ClassDataBase.trainingCourses.UpdateStatusInProcess();
                    ClassDataBase.trainingCourses.UpdateStatusEnd();
                    ClassDataBase.trainingCourses.SaveChanges();
                    ClassFrame.frame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
