﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using Excel = Microsoft.Office.Interop.Excel;
using TrainingCoursesApp.pageApp.pageAdmin;

namespace TrainingCoursesApp.pageApp.pageAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageAdminOrganization.xaml
    /// </summary>
    public partial class PageAdminOrganization : Page
    {
        public PageAdminOrganization()
        {
            InitializeComponent();

            lvOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
        }

        private void btnAddOrganization_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frame.Navigate(new PageAdminOrganizationEditAdd());
        }

        private void btnEditOrganization_Click(object sender, RoutedEventArgs e)
        {
            if (lvOrganization.SelectedItems.Count > 1)
            {
                MessageBox.Show("Выделите только один объект из списка", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (lvOrganization.SelectedItems.Count == 1)
                ClassFrame.frame.Navigate(new PageAdminOrganizationEditAdd(lvOrganization.SelectedItem as Organization));
        }

        private void btnDeleteOrganization_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvOrganization.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {lvOrganization.SelectedItems.Count} запись(-и)?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < lvOrganization.SelectedItems.Count;)
                        {
                            Organization organization = lvOrganization.SelectedItems[i] as Organization;
                            if (organization != null)
                            {
                                ClassDataBase.trainingCourses.Organization.Remove(organization);
                                ClassDataBase.trainingCourses.SaveChanges();
                                lvOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        lvOrganization.SelectedIndex = -1;
                        MessageBox.Show("Удаление успешно завершено", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    if (result == MessageBoxResult.No) return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            lvOrganization.SelectedIndex = -1;
            lvOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
        }

        private void btnReportOrganization_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workBook;
            Organization organization = lvOrganization.SelectedItem as Organization;
            List<Course> courses = ClassDataBase.trainingCourses.Course.Where(x => x.IDOrganization == organization.OrganizationID).ToList();
            List<People> peoples = new List<People> { };
            for (int i = 0; i < courses.Count; i++)
            {
                int courseID = courses[i].CourseID;
                List<int> ids = ClassDataBase.trainingCourses.CoursePeople.Where(x => x.IDCourse == courseID).Select(x => x.IDPeople).ToList();
                for (int j = 0; j < ClassDataBase.trainingCourses.People.Where(x => ids.Contains(x.PeopleID)).ToList().Count; j++)
                {
                    if (!peoples.Contains(ClassDataBase.trainingCourses.People.Where(x => ids.Contains(x.PeopleID)).ToList()[j]))
                    {
                        peoples.Add(ClassDataBase.trainingCourses.People.Where(x => ids.Contains(x.PeopleID)).ToList()[j]);
                    }
                }
            }
            workBook = excelApp.Workbooks.Add();
            if (peoples.Count == 0)
            {
                MessageBox.Show("В данной организации никто курсы не проходил", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            for (int i = 0; i < peoples.Count; i++)
            {
                int idPeople = peoples[i].PeopleID;
                List<int> ids = ClassDataBase.trainingCourses.CoursePeople.Where(x => x.IDPeople == idPeople).Select(x => x.IDCourse).ToList();
                List<Course> coursesPeople = ClassDataBase.trainingCourses.Course.Where(x => ids.Contains(x.CourseID) && x.IDOrganization == organization.OrganizationID).ToList();
                int counter = 0;
                if (coursesPeople.Count == 0)
                    continue;
                Excel.Worksheet workSheet;
                workSheet = workBook.ActiveSheet as Excel.Worksheet;
                workSheet.Name = $"{peoples[i].FirstName} {peoples[i].SecondName} {peoples[i].ThirdName}";
                for (int j = 0; j < coursesPeople.Count; j++)
                {
                    workSheet.Cells[1, counter + 1] = "Название курса";
                    workSheet.Cells[1, counter + 2] = "Организация";
                    workSheet.Cells[1, counter + 3] = "Дата начала курса";
                    workSheet.Cells[1, counter + 4] = "Дата окончания курса";
                    workSheet.Cells[1, counter + 5] = "Количество часов";
                    workSheet.Cells[1, counter + 6] = "Количество участников";

                    workSheet.Cells[2, counter + 1] = coursesPeople[j].Program;
                    workSheet.Cells[2, counter + 2] = organization.Title;
                    workSheet.Cells[2, counter + 3] = coursesPeople[j].PlanStart;
                    workSheet.Cells[2, counter + 4] = coursesPeople[j].PlanEnd;
                    workSheet.Cells[2, counter + 5] = coursesPeople[j].CountHours;
                    workSheet.Cells[2, counter + 6] = coursesPeople[j].CountPeopleNow;

                    int idCourse = coursesPeople[j].CourseID;
                    List<int> idsEducator = ClassDataBase.trainingCourses.CourseEducatorTopic.Where(x => x.IDCourse == idCourse).Select(x => x.IDEducator).ToList();
                    List<int> idsTopic = ClassDataBase.trainingCourses.CourseEducatorTopic.Where(x => x.IDCourse == idCourse).Select(x => x.IDTopic).ToList();
                    List<Topic> topics =  ClassDataBase.trainingCourses.Topic.Where(x => idsTopic.Contains(x.TopicID)).ToList();
                    List<Educator> educators = ClassDataBase.trainingCourses.Educator.Where(x => idsEducator.Contains(x.EducatorID)).ToList();

                    workSheet.Cells[4, counter + 1] = "Тема курса";
                    workSheet.Cells[4, counter + 2] = "Преподаватель";
                    workSheet.Cells[4, counter + 3] = "Количество часов";

                    int len = 0;

                    for (int l = 0; l < topics.Count; l++)
                    {
                        workSheet.Cells[5 + l, counter + 1] = topics[l].Title;
                        workSheet.Cells[5 + l, counter + 2] = educators[l].FirstName + " " + educators[l].SecondName + " " + educators[l].ThirdName;
                        workSheet.Cells[5 + l, counter + 3] = topics[l].CountHours;
                        len = 5 + l;
                    }

                    Excel.Range rng = workSheet.Range[workSheet.Cells[1, counter + 1], workSheet.Cells[2, counter + 6]];
                    Excel.Range rng2 = workSheet.Range[workSheet.Cells[4, counter + 1], workSheet.Cells[len, counter + 3]];
                    Excel.Borders border = rng.Borders;
                    border.LineStyle = Excel.XlLineStyle.xlContinuous;
                    border = rng2.Borders;
                    border.LineStyle = Excel.XlLineStyle.xlContinuous;
                    Excel.Range rng3 = workSheet.Range[workSheet.Cells[1, 1], workSheet.Cells[len, counter + 6]];
                    rng3.EntireRow.AutoFit();
                    rng3.EntireColumn.AutoFit();
                    counter += 7;
                }
                // Вычисляем сумму этих чисел
                
                //rng.Formula = "=SUM(A1:L1)";
                //rng.FormulaHidden = false;

                // Выделяем границы у этой ячейки
                

                // Строим круговую диаграмму
                //Excel.ChartObjects chartObjs = (Excel.ChartObjects)workSheet.ChartObjects();
                //Excel.ChartObject chartObj = chartObjs.Add(5, 50, 300, 300);
                //Excel.Chart xlChart = chartObj.Chart;
                //Excel.Range rng2 = workSheet.Range["A1:L1"];
                // Устанавливаем тип диаграммы
                //xlChart.ChartType = Excel.XlChartType.xlPie;
                // Устанавливаем источник данных (значения от 1 до 10)
                //xlChart.SetSourceData(rng2);
                
                workBook.Sheets.Add(workSheet);
            }
            // Открываем созданный excel-файл
            workBook.SaveAs($@"{System.IO.Directory.GetCurrentDirectory()}\Отчёты\По организациям\{(lvOrganization.SelectedItem as Organization).Title}.xlsx");
            MessageBox.Show($@"Файл с именем '{workBook.Name}' сохранён в папку '{System.IO.Directory.GetCurrentDirectory()}\Отчёты\По организациям'",
                    "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            excelApp.Visible = true;
            excelApp.UserControl = true;
        }
    }
}
