﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using Word = Microsoft.Office.Interop.Word;
using TrainingCoursesApp.pageApp.pageAdmin;

namespace TrainingCoursesApp.pageApp.pageAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageAdminCoursePeople.xaml
    /// </summary>
    public partial class PageAdminCoursePeople : Page
    {
        public int courseID;
        public int peopleID;
        public PageAdminCoursePeople(int idCourse)
        {
            InitializeComponent();
            courseID = idCourse;
            List<int> ids = ClassDataBase.trainingCourses.CoursePeople.Where(x => x.IDCourse == courseID).Select(x => x.IDPeople).ToList(); 
            lvPeople.ItemsSource = ClassDataBase.trainingCourses.People.Where(x => ids.Contains(x.PeopleID)).ToList();
        }

        private void btnOut_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvPeople.SelectedItems.Count == 1)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите выгнать участника?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        int idPeople = Convert.ToInt32(lvPeople.SelectedValue);
                        People people = ClassDataBase.trainingCourses.People.FirstOrDefault(x => x.PeopleID == idPeople);
                        ClassDataBase.trainingCourses.People.Remove(people);
                        ClassDataBase.trainingCourses.SaveChanges();
                        lvPeople.ItemsSource = ClassDataBase.trainingCourses.PeopleFIO(courseID).ToList();
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Выберите одного участника", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                lvPeople.SelectedIndex = -1;
                MessageBox.Show("Участник успешно выгнан", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCertificate_Click(object sender, RoutedEventArgs e)
        {
            Word.Document doc = null;
            try
            {
                // Создаём объект приложения
                Word.Application app = new Word.Application();
                // Путь до шаблона документа
                string source = $@"{System.IO.Directory.GetCurrentDirectory()}\Certificate.docx";
                // Открываем
                doc = app.Documents.Add(source);
                doc.Activate();

                // Добавляем информацию
                // wBookmarks содержит все закладки
                Word.Bookmarks wBookmarks = doc.Bookmarks;
                Word.Range wRange;
                int i = 0;
                Course course = ClassDataBase.trainingCourses.Course.FirstOrDefault(x => x.CourseID == courseID);
                People people = lvPeople.SelectedItem as People;
                int organizationID = int.Parse(course.IDOrganization.ToString());
                Organization organization = ClassDataBase.trainingCourses.Organization.FirstOrDefault(x => x.OrganizationID == organizationID);
                string[] data = new string[15] {
                    organization.City,
                    DateFormat(course.PlanEnd),
                    DateFormat(course.PlanEnd),
                    DateFormat(course.PlanStart),
                    people.FirstName,
                    course.CountHours.ToString(),
                    organization.Title,
                    organization.Title,
                    course.Program,
                    organization.Rector,
                    organization.Region,
                    ClassDataBase.trainingCourses.SelectRegistrationNumber(course.CourseID, people.PeopleID).ToList()[0].ToString(),
                    people.SecondName + " " + people.ThirdName,
                    organization.Secretary,
                    DateTime.Today.Year.ToString()};
                foreach (Word.Bookmark mark in wBookmarks)
                {
                    wRange = mark.Range;
                    wRange.Text = data[i];
                    i++;
                }

                // Закрываем документ
                doc.SaveAs2($@"{System.IO.Directory.GetCurrentDirectory()}\Сертификаты\{people.FirstName} {people.SecondName} {people.ThirdName}");
                MessageBox.Show($@"Файл с именем '{doc.Name}' сохранён в папку '{System.IO.Directory.GetCurrentDirectory()}\Сертификаты'",
                    "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                doc.Close();
                doc = null;
            }
            catch (Exception ex)
            {
                // Если произошла ошибка, то закрываем документ и выводим информацию
                MessageBox.Show($"Во время выполнения произошла ошибка: {ex}");
                doc.Close();
                doc = null;
            }
        }
        public string DateFormat(DateTime date)
        {
            string[] monthString = new string[] { "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря" };
            string month = monthString[date.Month - 1];
            return $"{date.Day} {month} {date.Year}";
        }
    }
}
