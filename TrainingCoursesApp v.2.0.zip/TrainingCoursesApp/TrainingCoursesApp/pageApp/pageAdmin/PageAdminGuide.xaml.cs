﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp.pageAdmin;

namespace TrainingCoursesApp.pageApp.pageAdmin
{
    /// <summary>
    /// Логика взаимодействия для PageAdminGuide.xaml
    /// </summary>
    public partial class PageAdminGuide : Page
    {
        public int idTopic;
        public int idQualification;
        public PageAdminGuide()
        {
            InitializeComponent();

            lvQualification.ItemsSource = ClassDataBase.trainingCourses.Qualification.ToList();
            lvTopic.ItemsSource = ClassDataBase.trainingCourses.Topic.ToList();
        }

        private void btnAddQualification_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (btnAddQualification.Content.ToString() == "Сохранить")
                {
                    ClassDataBase.trainingCourses.UpdateQualification(idQualification, txbxQualification.Text);
                    ClassDataBase.trainingCourses.SaveChanges();
                    lvQualification.SelectedIndex = -1;
                    lvQualification.ItemsSource = ClassDataBase.trainingCourses.Qualification.ToList();
                    btnAddQualification.Content = "Добавить";
                    txbxQualification.Text = "";
                }
                else
                {
                    Qualification qualification = new Qualification()
                    {
                        Title = txbxQualification.Text
                    };
                    ClassDataBase.trainingCourses.Qualification.Add(qualification);
                    ClassDataBase.trainingCourses.SaveChanges();
                    lvQualification.SelectedIndex = -1;
                    lvQualification.ItemsSource = ClassDataBase.trainingCourses.Qualification.ToList();
                    txbxQualification.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnDeleteQualification_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvQualification.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {lvQualification.SelectedItems.Count} запись(-и)?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < lvQualification.SelectedItems.Count;)
                        {
                            Qualification qualification = lvQualification.SelectedItems[i] as Qualification;
                            if (qualification != null)
                            {
                                ClassDataBase.trainingCourses.Qualification.Remove(qualification);
                                ClassDataBase.trainingCourses.SaveChanges();
                                lvQualification.ItemsSource = ClassDataBase.trainingCourses.Qualification.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        lvQualification.SelectedIndex = -1;
                        MessageBox.Show("Удаление успешно завершено", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    if (result == MessageBoxResult.No) return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAddTopic_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (btnAddTopic.Content.ToString() == "Сохранить")
                {
                    ClassDataBase.trainingCourses.UpdateTopic(idTopic, txbxTopic.Text, int.Parse(txbxHour.Text));
                    ClassDataBase.trainingCourses.SaveChanges();
                    lvTopic.SelectedIndex = -1;
                    lvTopic.ItemsSource = ClassDataBase.trainingCourses.Topic.ToList();
                    btnAddTopic.Content = "Добавить";
                    txbxTopic.Text = "";
                    txbxHour.Text = "";
                }
                else
                {
                    Topic topic = new Topic()
                    {
                        Title = txbxTopic.Text,
                        CountHours = int.Parse(txbxHour.Text)
                    };
                    ClassDataBase.trainingCourses.Topic.Add(topic);
                    ClassDataBase.trainingCourses.SaveChanges();
                    lvTopic.SelectedIndex = -1;
                    lvTopic.ItemsSource = ClassDataBase.trainingCourses.Topic.ToList();
                    txbxTopic.Text = "";
                    txbxHour.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnDeleteTopic_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvTopic.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {lvTopic.SelectedItems.Count} запись(-и)?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < lvTopic.SelectedItems.Count;)
                        {
                            Topic topic = lvTopic.SelectedItems[i] as Topic;
                            if (topic != null)
                            {
                                ClassDataBase.trainingCourses.Topic.Remove(topic);
                                ClassDataBase.trainingCourses.SaveChanges();
                                lvTopic.ItemsSource = ClassDataBase.trainingCourses.Topic.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        lvTopic.SelectedIndex = -1;
                        MessageBox.Show("Удаление успешно завершено", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    if (result == MessageBoxResult.No) return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnEditQualification_Click(object sender, RoutedEventArgs e)
        {
            if (lvQualification.SelectedItems.Count == 0)
            {
                return;
            }
            else
            {
                if (lvQualification.SelectedItems.Count > 1)
                {
                    MessageBox.Show("Выделите только один объект из списка", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                else
                {
                    txbxQualification.Text = (lvQualification.SelectedItem as Qualification).Title;
                    btnAddQualification.Content = "Сохранить";
                    idQualification = (lvQualification.SelectedItem as Qualification).QualificationID;
                }
            }
        }

        private void btnEditTopic_Click(object sender, RoutedEventArgs e)
        {
            if (lvTopic.SelectedItems.Count == 0)
            {
                return;
            }
            else
            {
                if (lvTopic.SelectedItems.Count > 1)
                {
                    MessageBox.Show("Выделите только один объект из списка", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                else
                {
                    txbxTopic.Text = (lvTopic.SelectedItem as Topic).Title;
                    txbxHour.Text = (lvTopic.SelectedItem as Topic).CountHours.ToString();
                    btnAddTopic.Content = "Сохранить";
                    idTopic = (lvTopic.SelectedItem as Topic).TopicID;
                }
            }
        }
    }
}
