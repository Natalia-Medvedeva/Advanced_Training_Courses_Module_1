﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp;

namespace TrainingCoursesApp.pageApp.pageGeneral
{
    /// <summary>
    /// Логика взаимодействия для PageAuthorization.xaml
    /// </summary>
    public partial class PageAuthorization : Page
    {
        public PageAuthorization()
        {
            InitializeComponent();
        }

        private void btnAuthorization_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                People peopleFull = ClassDataBase.trainingCourses.People.FirstOrDefault(x => x.Login == txbxLogin.Text && x.Password == txbxPassword.Text);
                People people = ClassDataBase.trainingCourses.People.FirstOrDefault(x => x.Login == txbxLogin.Text);

                Educator educatorFull = ClassDataBase.trainingCourses.Educator.FirstOrDefault(x => x.Login == txbxLogin.Text && x.Password == txbxPassword.Text);
                Educator educator = ClassDataBase.trainingCourses.Educator.FirstOrDefault(x => x.Login == txbxLogin.Text);

                if (peopleFull != people || educatorFull != educator)
                {
                    MessageBox.Show("Неверный пароль", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                if (peopleFull == null && educatorFull == null)
                {
                    MessageBox.Show("Данный пользователь отсутствует", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                else
                {
                    if (peopleFull != null)
                    {
                        if (peopleFull.IDCategory == 1)
                        {
                            ClassFrame.frame.Navigate(new pageAdmin.PageAdminMain());
                        }
                        else
                        {
                            ClassFrame.frame.Navigate(new pageListener.PageListenerCourse(peopleFull.PeopleID));
                        }
                    }
                    if (educatorFull != null)
                    {
                        MessageBox.Show("Данный преподаватель найден", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message.ToString(), "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
        }

        private void btnRegistration_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frame.Navigate(new PageRegistration());
        }
    }
}
