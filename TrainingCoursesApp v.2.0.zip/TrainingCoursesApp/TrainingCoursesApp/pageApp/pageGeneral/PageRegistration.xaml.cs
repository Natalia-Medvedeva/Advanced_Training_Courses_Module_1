﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using TrainingCoursesApp.pageApp;

namespace TrainingCoursesApp.pageApp.pageGeneral
{
    /// <summary>
    /// Логика взаимодействия для PageRegistration.xaml
    /// </summary>
    public partial class PageRegistration : Page
    {
        public PageRegistration()
        {
            InitializeComponent();

            cmbOrganization.ItemsSource = ClassDataBase.trainingCourses.Organization.ToList();
            cmbOrganization.SelectedValuePath = "OrganizationID";
            cmbOrganization.DisplayMemberPath = "Title";

            cmbQualification.ItemsSource = ClassDataBase.trainingCourses.Qualification.ToList();
            cmbQualification.SelectedValuePath = "QualificationID";
            cmbQualification.DisplayMemberPath = "Title";
        }

        private void btnRegIn_Click(object sender, RoutedEventArgs e)
        {
            if (ClassDataBase.trainingCourses.People.Count(x => x.Login == txbxLogin.Text) > 0 ||
                ClassDataBase.trainingCourses.Educator.Count(x => x.Login == txbxLogin.Text) > 0)
            {
                MessageBox.Show("Данный пользователь уже существует", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                ClassFrame.frame.GoBack();
                return;
            }
            else
            {
                if (txbxFirstName.Text.Length == 0)
                {
                    MessageBox.Show("Введите фамилию",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    txbxFirstName.Focus();
                    return;
                }
                if (txbxSecondName.Text.Length == 0)
                {
                    MessageBox.Show("Введите имя",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    txbxSecondName.Focus();
                    return;
                }
                if (txbxLogin.Text.Length == 0)
                {
                    MessageBox.Show("Введите логин",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    txbxLogin.Focus();
                    return;
                }
                if (txbxPassword.Text.Length == 0)
                {
                    MessageBox.Show("Введите пароль",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    txbxPassword.Focus();
                    return;
                }
                if (rbtnEducator.IsChecked == true && cmbOrganization.SelectedIndex == -1)
                {
                    MessageBox.Show("Выберите организацию",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    cmbOrganization.Focus();
                    return;
                }
                if (rbtnEducator.IsChecked == true && cmbQualification.SelectedIndex == -1)
                {
                    MessageBox.Show("Выберите квалификацию",
                            "Уведомление",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                    cmbOrganization.Focus();
                    return;
                }
                try
                {
                    if (rbtnEducator.IsChecked == true)
                    {
                        Educator educator = new Educator()
                        {
                            FirstName = txbxFirstName.Text,
                            SecondName = txbxSecondName.Text,
                            ThirdName = txbxThirdName.Text,
                            Age = int.Parse(txbxAge.Text),
                            Login = txbxLogin.Text,
                            Password = txbxPassword.Text,
                            IDOrganization = (cmbOrganization.SelectedItem as Organization).OrganizationID,
                            IDQualification = (cmbQualification.SelectedItem as Qualification).QualificationID,
                        };
                        ClassDataBase.trainingCourses.Educator.Add(educator);
                        ClassDataBase.trainingCourses.SaveChanges();
                        MessageBox.Show("Пользователь успешно зарегистрирован (Преподаватель)", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                        ClassFrame.frame.GoBack();
                    }
                    else
                    {
                        int ID = 0;
                        if (rbtnAdmin.IsChecked == true)
                        {
                            ID = 1;
                        }
                        else
                        {
                            ID = 2;
                        }
                        People people = new People()
                        {
                            FirstName = txbxFirstName.Text,
                            SecondName = txbxSecondName.Text,
                            ThirdName = txbxThirdName.Text,
                            Age = int.Parse(txbxAge.Text),
                            Login = txbxLogin.Text,
                            Password = txbxPassword.Text,
                            IDCategory = ID
                        };
                        ClassDataBase.trainingCourses.People.Add(people);
                        ClassDataBase.trainingCourses.SaveChanges();
                        if (rbtnAdmin.IsChecked == true)
                        {
                            MessageBox.Show("Пользователь успешно зарегистрирован (Администратор)", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("Пользователь успешно зарегистрирован (Обучающийся)", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        ClassFrame.frame.GoBack();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message.ToString(), "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }

        private void sldAge_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            txbxAge.Text = Convert.ToInt32(sldAge.Value).ToString();
        }

        private void rbtnEducator_Checked(object sender, RoutedEventArgs e)
        {
            lblOrganization.IsEnabled = true;
            cmbOrganization.IsEnabled = true;
            lblQualification.IsEnabled = true;
            cmbQualification.IsEnabled = true;
        }

        private void rbtnEducator_Unchecked(object sender, RoutedEventArgs e)
        {
            lblOrganization.IsEnabled = false;
            cmbOrganization.IsEnabled = false;
            cmbOrganization.SelectedIndex = -1;
            lblQualification.IsEnabled = false;
            cmbQualification.IsEnabled = false;
            cmbQualification.SelectedIndex = -1;
        }
    }
}
