﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainingCoursesApp.data;
using Word = Microsoft.Office.Interop.Word;
using TrainingCoursesApp.pageApp.pageListener;

namespace TrainingCoursesApp.pageApp.pageListener
{
    /// <summary>
    /// Логика взаимодействия для PageListenerCourse.xaml
    /// </summary>
    public partial class PageListenerCourse : Page
    {
        public int peopleID;
        public List<int> ids;
        public PageListenerCourse(int idPeople)
        {
            InitializeComponent();
            peopleID = idPeople;
            ClassDataBase.trainingCourses.UpdateCourseHoursPeopleCount();
            ClassDataBase.trainingCourses.UpdateStatusInProcess();
            ClassDataBase.trainingCourses.UpdateStatusEnd();
            ClassDataBase.trainingCourses.SaveChanges();
            ids = ClassDataBase.trainingCourses.CoursePeople.Where(x => x.IDPeople == peopleID).Select(x => x.IDCourse).ToList();
            lvCourse.ItemsSource = ClassDataBase.trainingCourses.Course.Where(x => ids.Contains(x.CourseID)).ToList();
        }

        private void btnOut_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lvCourse.SelectedItems.Count == 1)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите выйти из курса?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        Course course = lvCourse.SelectedItem as Course;
                        ClassDataBase.trainingCourses.DeleteCoursePeople(course.CourseID, peopleID);
                        ClassDataBase.trainingCourses.SaveChanges();
                        ids = ClassDataBase.trainingCourses.CoursePeople.Where(x => x.IDPeople == peopleID).Select(x => x.IDCourse).ToList();
                        lvCourse.ItemsSource = ClassDataBase.trainingCourses.Course.Where(x => ids.Contains(x.CourseID)).ToList();
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Выберите один курс для выхода", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                lvCourse.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnIn_Click(object sender, RoutedEventArgs e)
        {
            if (btnIn.Content.ToString() == "Записаться на курс")
            {
                btnCancel.IsEnabled = true;
                btnOutCourse.IsEnabled = false;
                btnIn.Content = "Записаться";
                Title = "Запись на курс";
                ids = ClassDataBase.trainingCourses.CoursePeople.Where(x => x.IDPeople == peopleID).Select(x => x.IDCourse).ToList();
                lvCourse.ItemsSource = ClassDataBase.trainingCourses.Course.Where(x => !ids.Contains(x.CourseID) && x.IDStatus == 1).ToList();
            }
            else
            {
                Course course = lvCourse.SelectedItem as Course;
                ClassDataBase.trainingCourses.AddCoursePeople(course.CourseID, peopleID);
                ClassDataBase.trainingCourses.UpdateCourseHoursPeopleCount();
                ClassDataBase.trainingCourses.UpdateStatusInProcess();
                ClassDataBase.trainingCourses.UpdateStatusEnd();
                ClassDataBase.trainingCourses.SaveChanges();
                btnCancel.IsEnabled = false;
                btnIn.Content = "Записаться на курс";
                Title = "Мои курсы";
                ids = ClassDataBase.trainingCourses.CoursePeople.Where(x => x.IDPeople == peopleID).Select(x => x.IDCourse).ToList();
                lvCourse.ItemsSource = ClassDataBase.trainingCourses.Course.Where(x => ids.Contains(x.CourseID)).ToList();
            }
        }
        private void lvCourse_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (btnIn.Content.ToString() == "Записаться на курс")
            {
                if (lvCourse.SelectedIndex == -1)
                {
                    return;
                }
                else
                {
                    int course = (lvCourse.SelectedItem as Course).CourseID;
                    CoursePeople coursePeople = ClassDataBase.trainingCourses.CoursePeople.FirstOrDefault(x => x.IDCourse == course && x.IDPeople == peopleID);
                    if (coursePeople == null || (lvCourse.SelectedItem as Course).IDStatus == 3)
                        btnOutCourse.IsEnabled = false;
                    else btnOutCourse.IsEnabled = true;
                }
            }
        }

        public string DateFormat(DateTime date)
        {
            string[] monthString = new string[] { "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря" };
            string month = monthString[date.Month - 1];
            return $"{date.Day} {month} {date.Year}";
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassDataBase.trainingCourses.UpdateCourseHoursPeopleCount();
            ClassDataBase.trainingCourses.UpdateStatusInProcess();
            ClassDataBase.trainingCourses.UpdateStatusEnd();
            ClassDataBase.trainingCourses.SaveChanges();
            btnCancel.IsEnabled = false;
            btnIn.Content = "Записаться на курс";
            Title = "Мои курсы";
            ids = ClassDataBase.trainingCourses.CoursePeople.Where(x => x.IDPeople == peopleID).Select(x => x.IDCourse).ToList();
            lvCourse.ItemsSource = ClassDataBase.trainingCourses.Course.Where(x => ids.Contains(x.CourseID)).ToList();
        }
    }
}
